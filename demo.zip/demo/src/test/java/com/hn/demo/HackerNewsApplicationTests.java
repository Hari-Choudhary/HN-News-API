package com.hn.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HackerNewsApplicationTests {

	@Test
	void contextLoads() {
	}

}
